"""
Failsafe Console — FINAL (Safe)
- Voice/passphrase auth (fallback manual)
- Command console accepting:
    Initiate self destruct sequence code 101,102,103,104
- 60s countdown with Abort (voice/button) and No Mercy (disable abort)
- 101: send real email via Gmail SMTP (requires App Password)
- 102: move selected files to Recycle Bin (send2trash) at T=0 (recoverable)
- 103: dramatic mock System32 prank (no real deletion). Optional logoff only after confirmation.
- 104: object attach flow -> announces "Object activated" at T=0
- Soothing female TTS (pyttsx3). Voice recognition optional (SpeechRecognition + PyAudio).
- Logs actions to ~/failsafe_console_final.log
SAFETY: This script intentionally avoids irreversible destructive operations.
"""

import os
import re
import threading
import queue
import time
from datetime import datetime
import tkinter as tk
from tkinter import messagebox, filedialog, simpledialog, ttk, scrolledtext

# Optional voice libraries
try:
    import speech_recognition as sr
    SR_AVAILABLE = True
except Exception:
    SR_AVAILABLE = False

try:
    import pyttsx3
    TTS_AVAILABLE = True
except Exception:
    TTS_AVAILABLE = False

# send2trash for safe deletion (recycle bin)
try:
    from send2trash import send2trash
    SEND2TRASH_AVAILABLE = True
except Exception:
    SEND2TRASH_AVAILABLE = False

# Email
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# ---------------- CONFIG ----------------
SENDER_EMAIL = "sidhuamrinderpal@gmail.com"   # hardcoded sender
APP_PASSWORD = ""  # Enter your Gmail App Password at runtime  # leave blank to be prompted at runtime (recommended)
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

PASSPHRASE_RAW = "Computer this is Amrinder speaking"
PASSPHRASE = re.sub(r"[^a-z0-9\s]", " ", PASSPHRASE_RAW.lower()).strip()
COUNTDOWN_SECONDS = 60
LOG_FILE = os.path.join(os.path.expanduser("~"), "failsafe_console_final.log")
ABORT_PHRASES = ("abort self destruct", "abort sequence", "abort")
SUPPORTED_CODES = ("101", "102", "103", "104")
# ----------------------------------------

def log(msg: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass
    print(line)

def normalize_text(s: str) -> str:
    s = (s or "").lower()
    s = re.sub(r"[^a-z0-9\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

# ---------------- TTS ----------------
def init_tts():
    if not TTS_AVAILABLE:
        return None
    try:
        eng = pyttsx3.init()
        voices = eng.getProperty("voices")
        chosen = None
        for v in voices:
            name = (v.name or "").lower()
            if "female" in name or "zira" in name or "samantha" in name:
                chosen = v.id
                break
        if chosen:
            eng.setProperty("voice", chosen)
        rate = eng.getProperty("rate")
        eng.setProperty("rate", int(rate * 0.95))
        return eng
    except Exception:
        return None

TTS = init_tts()

def speak(text: str):
    def _do():
        try:
            if TTS:
                TTS.say(text)
                TTS.runAndWait()
        except Exception:
            pass
    log("[TTS] " + text)
    threading.Thread(target=_do, daemon=True).start()

# --------------- Voice capture helpers ---------------
class SingleCapture(threading.Thread):
    def __init__(self, out_q: queue.Queue, timeout=6, phrase_time_limit=6):
        super().__init__(daemon=True)
        self.q = out_q
        self.timeout = timeout
        self.phrase_time_limit = phrase_time_limit

    def run(self):
        if not SR_AVAILABLE:
            self.q.put("")
            return
        r = sr.Recognizer()
        try:
            with sr.Microphone() as src:
                r.adjust_for_ambient_noise(src, duration=0.5)
                audio = r.listen(src, timeout=self.timeout, phrase_time_limit=self.phrase_time_limit)
            try:
                txt = r.recognize_google(audio)
            except sr.UnknownValueError:
                txt = ""
            except sr.RequestError:
                txt = ""
            self.q.put(txt)
        except Exception:
            self.q.put("")

class AbortListener(threading.Thread):
    def __init__(self, out_q: queue.Queue, stop_event: threading.Event):
        super().__init__(daemon=True)
        self.q = out_q
        self.stop_event = stop_event

    def run(self):
        if not SR_AVAILABLE:
            return
        r = sr.Recognizer()
        try:
            mic = sr.Microphone()
        except Exception:
            return
        while not self.stop_event.is_set():
            try:
                with mic as src:
                    r.adjust_for_ambient_noise(src, duration=0.4)
                    audio = r.listen(src, timeout=3, phrase_time_limit=3)
                try:
                    txt = r.recognize_google(audio)
                except sr.UnknownValueError:
                    txt = ""
                except sr.RequestError:
                    txt = ""
                if txt:
                    self.q.put(txt)
            except Exception:
                pass

# ---------------- GUI APP ----------------
class FailsafeApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Failsafe Console — Final (Safe)")
        self.geometry("880x680")
        self.resizable(False, False)

        self.container = tk.Frame(self)
        self.container.pack(fill="both", expand=True, padx=12, pady=12)

        self.login_frame = LoginFrame(self.container, self.on_auth_success)
        self.login_frame.pack(fill="both", expand=True)

        speak("Starting Failsafe Console. Please authenticate with your passphrase or use manual login.")

    def on_auth_success(self):
        self.login_frame.pack_forget()
        self.console_frame = ConsoleFrame(self.container, on_exit=self.quit_app)
        self.console_frame.pack(fill="both", expand=True)

    def quit_app(self):
        try:
            self.console_frame.shutdown()
        except Exception:
            pass
        self.destroy()

# ---------------- Login Frame ----------------
class LoginFrame(tk.Frame):
    def __init__(self, master, on_success):
        super().__init__(master)
        self.on_success = on_success
        self.q = queue.Queue()

        tk.Label(self, text="Commander Authentication", font=("Segoe UI", 18, "bold")).pack(pady=(6,6))
        tk.Label(self, text="Primary: Voice passphrase. Fallback: manual login.", font=("Segoe UI", 10)).pack()

        self.status = tk.Label(self, text="Press Listen and say the passphrase.", fg="#155")
        self.status.pack(pady=(8,8))

        bf = tk.Frame(self)
        bf.pack(pady=6)
        self.listen_btn = tk.Button(bf, text="Listen (Voice Passphrase)", width=28, command=self.listen_passphrase)
        self.listen_btn.grid(row=0, column=0, padx=8)
        self.retry_btn = tk.Button(bf, text="Retry", width=12, command=self.reset_status)
        self.retry_btn.grid(row=0, column=1, padx=6)

        tk.Label(self, text=f'Expected passphrase:\n"{PASSPHRASE_RAW}"', fg="#666").pack(pady=(8,12))

        lf = tk.LabelFrame(self, text="Manual Login (Fallback)", padx=8, pady=8)
        lf.pack(pady=(6,10), fill="x")
        tk.Label(lf, text="Username:").grid(row=0, column=0, sticky="e", padx=6, pady=4)
        tk.Label(lf, text="Password:").grid(row=1, column=0, sticky="e", padx=6, pady=4)
        self.user_entry = tk.Entry(lf, width=32)
        self.pw_entry = tk.Entry(lf, width=32, show="•")
        self.user_entry.grid(row=0, column=1, pady=4)
        self.pw_entry.grid(row=1, column=1, pady=4)
        self.login_btn = tk.Button(lf, text="Login (Manual)", command=self.manual_login)
        self.login_btn.grid(row=2, column=0, columnspan=2, pady=(8,4))

        if not SR_AVAILABLE:
            self.status.config(text="Voice unavailable (SpeechRecognition/PyAudio not installed). Use manual login.")
            speak("Voice not available. Please use manual login.")

    def reset_status(self):
        self.status.config(text="Press Listen and say the passphrase.")
        self.user_entry.delete(0, tk.END)
        self.pw_entry.delete(0, tk.END)

    def listen_passphrase(self):
        if not SR_AVAILABLE:
            messagebox.showwarning("Voice Unavailable", "SpeechRecognition / PyAudio not installed.")
            return
        self.listen_btn.config(state=tk.DISABLED)
        self.status.config(text="Listening...")
        speak("Listening for passphrase now.")
        def worker():
            cap = SingleCapture(self.q)
            cap.start()
            heard = self.q.get()
            self.after(0, self._on_heard, heard)
        threading.Thread(target=worker, daemon=True).start()

    def _on_heard(self, heard: str):
        self.listen_btn.config(state=tk.NORMAL)
        if not heard:
            self.status.config(text="Could not understand. Try manual login or retry.")
            speak("I could not understand. Please try again or use manual login.")
            log("Voice auth: nothing recognized.")
            return
        self.status.config(text=f'Heard: "{heard}"')
        log(f"Voice auth heard: {heard}")
        if normalize_text(heard) == PASSPHRASE:
            speak("Authentication successful. Welcome, Commander Amrinder.")
            log("Authentication success (voice).")
            self.on_success()
        else:
            speak("Passphrase mismatch. Try manual login or retry.")
            log(f"Authentication failed (voice) - heard: {heard}")
            messagebox.showerror("Access Denied", "Voice passphrase did not match.")

    def manual_login(self):
        u = self.user_entry.get().strip()
        p = self.pw_entry.get().strip()
        if u == "Amrinder" and p == "commander":
            speak("Manual authentication successful. Welcome, Commander Amrinder.")
            log("Authentication success (manual).")
            self.on_success()
        else:
            speak("Manual authentication failed.")
            log("Authentication failed (manual).")
            messagebox.showerror("Access Denied", "Invalid credentials.")

# ---------------- Console Frame ----------------
class ConsoleFrame(tk.Frame):
    def __init__(self, master, on_exit):
        super().__init__(master)
        self.on_exit = on_exit
        self.abort_q = queue.Queue()
        self.abort_stop = None
        self.abort_thread = None

        self.current_code = None
        self.selected_files = []
        self.countdown_active = False
        self.abort_enabled = True
        self.remaining = COUNTDOWN_SECONDS

        header = tk.Label(self, text="Access Granted — Commander Console", font=("Segoe UI", 16, "bold"))
        header.pack(pady=(6,4))
        tk.Label(self, text="Speak or type: 'Initiate self destruct sequence code <101|102|103|104>'", font=("Segoe UI", 10)).pack()

        top = tk.Frame(self)
        top.pack(pady=8)
        self.cmd_var = tk.StringVar()
        self.cmd_entry = tk.Entry(top, width=76, textvariable=self.cmd_var)
        self.cmd_entry.grid(row=0, column=0, padx=(6,8))
        self.listen_cmd_btn = tk.Button(top, text="Listen (Voice Command)", command=self.listen_command)
        self.listen_cmd_btn.grid(row=0, column=1, padx=(0,8))
        self.submit_cmd_btn = tk.Button(top, text="Submit (Type)", command=self.process_command)
        self.submit_cmd_btn.grid(row=0, column=2)

        # details area
        self.details_frame = tk.LabelFrame(self, text="Action Details", padx=8, pady=8)
        self.details_frame.pack(padx=12, pady=8, fill="x")
        self.details_label = tk.Label(self.details_frame, text="No action selected yet.", fg="#666")
        self.details_label.pack()

        # dynamic holder for code-specific widgets
        self.dynamic_holder = tk.Frame(self.details_frame)
        self.dynamic_holder.pack(fill="x", pady=6)

        # countdown controls
        ctrls = tk.Frame(self)
        ctrls.pack(pady=6)
        self.count_label = tk.Label(ctrls, text="Countdown: —", font=("Consolas", 14))
        self.count_label.grid(row=0, column=0, padx=8)
        self.start_btn = tk.Button(ctrls, text="Start Sequence", state=tk.DISABLED, command=self.start_sequence)
        self.start_btn.grid(row=0, column=1, padx=6)
        self.abort_btn = tk.Button(ctrls, text="Abort", state=tk.DISABLED, command=self.abort_sequence)
        self.abort_btn.grid(row=0, column=2, padx=6)
        self.no_mercy_btn = tk.Button(ctrls, text="No Mercy", state=tk.NORMAL, command=self.no_mercy)
        self.no_mercy_btn.grid(row=0, column=3, padx=6)
        self.exit_btn = tk.Button(ctrls, text="Exit App", command=self.on_exit_pressed)
        self.exit_btn.grid(row=0, column=4, padx=8)

        # log area
        self.log_box = tk.Text(self, width=102, height=16, state=tk.DISABLED)
        self.log_box.pack(pady=(8,6))

        speak("Access granted. Please give your command by speaking or typing.")
        self.log("Console ready. Awaiting command.")
        self.after(400, self._poll_abort_queue)

    def log(self, txt: str):
        self.log_box.config(state=tk.NORMAL)
        self.log_box.insert(tk.END, txt + "\n")
        self.log_box.see(tk.END)
        self.log_box.config(state=tk.DISABLED)
        log(txt)

    # ------------- Command capture -------------
    def listen_command(self):
        if not SR_AVAILABLE:
            messagebox.showwarning("Voice Unavailable", "SpeechRecognition / PyAudio not installed.")
            return
        self.listen_cmd_btn.config(state=tk.DISABLED)
        speak("Listening for your command now.")
        q = queue.Queue()
        def worker():
            cap = SingleCapture(q)
            cap.start()
            heard = q.get()
            self.after(0, self._on_cmd_heard, heard)
        threading.Thread(target=worker, daemon=True).start()

    def _on_cmd_heard(self, heard: str):
        self.listen_cmd_btn.config(state=tk.NORMAL)
        if not heard:
            speak("I didn't catch that. Try typing the command.")
            self.log("Voice command not recognized.")
            return
        self.cmd_var.set(heard)
        self.log(f"Voice command captured: {heard}")
        speak(f"I heard: {heard}. Processing.")
        self.process_command()

    def process_command(self):
        txt = self.cmd_var.get().strip()
        if not txt:
            messagebox.showinfo("No command", "Please type a command or use Listen.")
            return
        norm = normalize_text(txt)
        if not norm.startswith("initiate self destruct sequence code"):
            speak("Invalid command format. Use: Initiate self destruct sequence code <code>.")
            messagebox.showerror("Invalid format", "Use: Initiate self destruct sequence code <code>.")
            self.log(f"Invalid command: {txt}")
            return
        tokens = norm.split()
        code = None
        for t in tokens:
            if t in SUPPORTED_CODES:
                code = t
                break
        if not code:
            speak("No supported code found. Supported codes: 101, 102, 103, 104.")
            messagebox.showerror("Invalid code", "Supported codes: 101, 102, 103, 104.")
            self.log("Code not found in command.")
            return

        self.current_code = code
        self.log(f"Command accepted: code {code}")
        self.show_details_for_code(code)
        self.start_btn.config(state=tk.NORMAL)
        self.abort_btn.config(state=tk.DISABLED)
        self.no_mercy_btn.config(state=tk.NORMAL)
        self.count_label.config(text="Countdown: —")
        speak(f"Code {code} selected. Provide required details then press Start Sequence.")

    # ------------- UI per code -------------
    def clear_dynamic(self):
        for w in self.dynamic_holder.winfo_children():
            w.destroy()
        self.selected_files = []

    def show_details_for_code(self, code: str):
        self.clear_dynamic()
        self.details_label.config(text=f"Code {code} selected.")
        if code == "101":
            tk.Label(self.dynamic_holder, text="Target Email:").grid(row=0, column=0, sticky="e", padx=6, pady=4)
            self.email_entry = tk.Entry(self.dynamic_holder, width=64)
            self.email_entry.grid(row=0, column=1, pady=4, sticky="w")
            tk.Label(self.dynamic_holder, text="Subject:").grid(row=1, column=0, sticky="e", padx=6, pady=4)
            self.subject_entry = tk.Entry(self.dynamic_holder, width=64)
            self.subject_entry.grid(row=1, column=1, pady=4, sticky="w")
            tk.Label(self.dynamic_holder, text="Message (large area):").grid(row=2, column=0, sticky="ne", padx=6, pady=4)
            self.msg_text = scrolledtext.ScrolledText(self.dynamic_holder, width=64, height=8)
            self.msg_text.grid(row=2, column=1, pady=4, sticky="w")
        elif code == "102":
            tk.Label(self.dynamic_holder, text="Files to queue (will be moved to Recycle Bin):").pack(anchor="w")
            self.files_listbox = tk.Listbox(self.dynamic_holder, width=100, height=6)
            self.files_listbox.pack(pady=(4,6))
            btns = tk.Frame(self.dynamic_holder)
            btns.pack()
            tk.Button(btns, text="Add Files", command=self.add_files).grid(row=0, column=0, padx=6)
            tk.Button(btns, text="Clear List", command=self.clear_files).grid(row=0, column=1, padx=6)
            hint = "Files will be moved to Recycle Bin at execution (recoverable)."
            tk.Label(self.dynamic_holder, text=hint, fg="#a60").pack(anchor="w", pady=(6,0))
        elif code == "103":
            tk.Label(self.dynamic_holder, text="[SIMULATION] System-level action will be simulated at T=0.", fg="#a00", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=8)
            
        elif code == "104":
            tk.Label(self.dynamic_holder, text="Attach the required object (physically) and then start the timer.", fg="#064").pack(anchor="w", pady=6)
            tk.Label(self.dynamic_holder, text="Once timer reaches 0 the system will say 'Object activated'.").pack(anchor="w")

    def add_files(self):
        files = filedialog.askopenfilenames(title="Select files to queue (will go to Recycle Bin at execution)")
        if not files:
            return
        for f in files:
            if f not in self.selected_files:
                self.selected_files.append(f)
                self.files_listbox.insert(tk.END, f)
        self.log(f"{len(files)} file(s) added to queue (to Recycle Bin at T=0).")

    def clear_files(self):
        self.selected_files = []
        try:
            self.files_listbox.delete(0, tk.END)
        except Exception:
            pass
        self.log("File queue cleared.")

    # ------------- Countdown & controls -------------
    def start_sequence(self):
        code = self.current_code
        if not code:
            messagebox.showerror("No code", "Select a code first.")
            return
        if code == "101":
            email = getattr(self, "email_entry", None).get().strip() if getattr(self, "email_entry", None) else ""
            subj = getattr(self, "subject_entry", None).get().strip() if getattr(self, "subject_entry", None) else ""
            msg = getattr(self, "msg_text", None).get("1.0", tk.END).strip() if getattr(self, "msg_text", None) else ""
            if not email or not subj or not msg:
                messagebox.showerror("Missing details", "Enter target email, subject and message for code 101.")
                return
        if code == "102" and not self.selected_files:
            messagebox.showerror("No files", "Add at least one file for code 102.")
            return
        if code == "102" and not SEND2TRASH_AVAILABLE:
            messagebox.showwarning("send2trash missing", "send2trash not installed. Install it to allow safe Recycle Bin moves.\nCommand:\n  pip install send2trash")
            return

        self.countdown_active = True
        self.abort_enabled = True
        self.remaining = COUNTDOWN_SECONDS
        self.start_btn.config(state=tk.DISABLED)
        self.abort_btn.config(state=tk.NORMAL)
        self.no_mercy_btn.config(state=tk.NORMAL)
        self.log(f"Sequence STARTED for code {code}. Abort ENABLED.")
        speak(f"Sequence initiated for code {code}. T minus {COUNTDOWN_SECONDS} seconds. Abort is enabled.")
        # start abort listener
        self.abort_q = queue.Queue()
        self.abort_stop = threading.Event()
        if SR_AVAILABLE:
            self.abort_thread = AbortListener(self.abort_q, self.abort_stop)
            self.abort_thread.start()
        self._tick()

    def _tick(self):
        if not self.countdown_active:
            return
        self.count_label.config(text=f"Countdown: T-{self.remaining:02d}s")
        if self.remaining <= 0:
            self.countdown_active = False
            if self.abort_stop:
                self.abort_stop.set()
            self.abort_btn.config(state=tk.DISABLED)
            self.no_mercy_btn.config(state=tk.DISABLED)
            self.count_label.config(text="Countdown: T-00s")
            self.execute_current_code()
            return
        self.remaining -= 1
        self._check_abort_queue()
        self.after(1000, self._tick)

    def _check_abort_queue(self):
        try:
            while not self.abort_q.empty():
                item = self.abort_q.get_nowait()
                norm = normalize_text(item)
                self.log(f"Voice during countdown: {item}")
                for ap in ABORT_PHRASES:
                    if ap in norm:
                        if self.abort_enabled and self.countdown_active:
                            self.log("Abort phrase detected. Aborting sequence.")
                            speak("Abort phrase detected. Sequence aborted.")
                            self.abort_sequence()
                            return
                        elif self.countdown_active and not self.abort_enabled:
                            speak("Abort ignored. No mercy is active.")
                            self.log("Abort ignored because No Mercy is active.")
                            return
        except Exception:
            pass

    def _poll_abort_queue(self):
        self._check_abort_queue()
        self.after(400, self._poll_abort_queue)

    def abort_sequence(self):
        if not self.countdown_active:
            return
        if not self.abort_enabled:
            self.log("Abort attempted but No Mercy active. Ignored.")
            speak("Abort ignored. No mercy active.")
            return
        self.countdown_active = False
        if self.abort_stop:
            self.abort_stop.set()
        self.start_btn.config(state=tk.NORMAL)
        self.abort_btn.config(state=tk.DISABLED)
        self.no_mercy_btn.config(state=tk.DISABLED)
        self.count_label.config(text="Countdown: —")
        self.log("Sequence aborted by user.")
        speak("Sequence aborted. Returning to console.")

    def no_mercy(self):
        self.abort_enabled = False
        self.abort_btn.config(state=tk.DISABLED)
        self.log("NO MERCY activated; abort disabled.")
        speak("No mercy activated. Abort disabled.")

    # ------------- Execution at T=0 -------------
    def execute_current_code(self):
        code = self.current_code
        self.log(f"Executing code {code} at T=0.")
        try:
            if code == "101":
                self._execute_101()
            elif code == "102":
                self._execute_102()
            elif code == "103":
                self._execute_103()
            elif code == "104":
                self._execute_104()
            else:
                self.log("Unknown code at execution.")
        except Exception as e:
            messagebox.showerror("Execution Error", str(e))
            self.log(f"Error during execution: {e}")
        finally:
            self.start_btn.config(state=tk.NORMAL)
            self.abort_btn.config(state=tk.DISABLED)
            self.no_mercy_btn.config(state=tk.DISABLED)
            self.count_label.config(text="Countdown: —")
            self.countdown_active = False
            if self.abort_stop:
                self.abort_stop.set()

    # ----- Code 101: Send real email (requires app password or prompt) -----
    def _execute_101(self):
        email = self.email_entry.get().strip()
        subject = self.subject_entry.get().strip()
        body = self.msg_text.get("1.0", tk.END).strip()

        global APP_PASSWORD
        if not APP_PASSWORD:
            APP_PASSWORD = simpledialog.askstring("Gmail App Password", "Enter Gmail App Password (16 chars)", show="*")
            if not APP_PASSWORD:
                speak("No app password provided. Cancelling email.")
                self.log("Code101 cancelled: no app password")
                messagebox.showwarning("Cancelled", "No app password provided. Email cancelled.")
                return

        speak("Sending email now.")
        self.log(f"[CODE101] Sending email to {email} (via {SENDER_EMAIL})")
        try:
            msg = MIMEMultipart()
            msg["From"] = SENDER_EMAIL
            msg["To"] = email
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain"))

            server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
            server.ehlo()
            server.starttls()
            server.login(SENDER_EMAIL, APP_PASSWORD)
            server.sendmail(SENDER_EMAIL, email, msg.as_string())
            server.quit()
            self.log(f"[CODE101] Email sent to {email}")
            speak("Email sent successfully.")
            messagebox.showinfo("Code 101", f"Email sent to {email}.")
        except Exception as e:
            self.log(f"[CODE101] Email failed: {e}")
            messagebox.showerror("Email Error", f"Failed to send email: {e}")

    # ----- Code 102: Move selected files to Recycle Bin (safe) -----
    def _execute_102(self):
        if not SEND2TRASH_AVAILABLE:
            messagebox.showwarning("send2trash missing", "send2trash not installed. Install via: pip install send2trash")
            return
        confirm = messagebox.askyesno("Confirm Move to Recycle Bin", f"Move {len(self.selected_files)} file(s) to Recycle Bin? (recoverable)")
        if not confirm:
            self.log("[CODE102] User cancelled Recycle Bin move.")
            speak("Deletion cancelled. No changes made.")
            return
        failures = []
        for f in list(self.selected_files):
            try:
                send2trash(f)
                self.log(f"[CODE102] Moved to Recycle Bin: {f}")
            except Exception as e:
                failures.append((f, str(e)))
        if failures:
            msg = "Some files could not be moved:\n" + "\n".join([f"{p}: {e}" for p, e in failures])
            messagebox.showwarning("Partial Failure", msg)
            self.log("[CODE102] Partial failures: " + str(failures))
        else:
            messagebox.showinfo("Code 102", "All selected files will be permanently deleted.")
            speak("Files moved to Recycle Bin.")

    # ----- Code 103: Mock System32 deletion (simulation), optional logoff -----
    def _execute_103(self):
        prank = tk.Toplevel(self)
        prank.title("System Critical - In Progress")
        prank.geometry("600x220")
        prank.config(bg="#200")
        tk.Label(prank, text="WARNING: Deleting C:\\Windows\\System32 ...", fg="#ffdddd", bg="#200", font=("Consolas", 14, "bold")).pack(pady=(12,8))
        pb = ttk.Progressbar(prank, length=520, mode="determinate", maximum=100)
        pb.pack(pady=12)
        status = tk.Label(prank, text="0% ...", fg="#fff", bg="#200")
        status.pack()

        steps = 12
        def run_progress(i=0):
            if i > steps:
                status.config(text="action complete.")
                speak("Action complete. No files were harmed.")
                self.log("[CODE103] Deletion completed.")
                def after_done():
                    want = messagebox.askyesno("Finish", "Simulation finished. Do you want to log off now?")
                    if want:
                        speak("Logging you off now.")
                        self.log("[CODE103] User confirmed logoff. Logging off.")
                        try:
                            if os.name == "nt":
                                os.system("shutdown -l")
                            else:
                                os.system("gnome-session-quit --logout --no-prompt || pkill -KILL -u $USER")
                        except Exception as e:
                            log(f"Logoff attempt failed: {e}")
                    else:
                        speak("Logoff cancelled. System unchanged.")
                prank.after(500, after_done)
                tk.Button(prank, text="Close", command=prank.destroy).pack(pady=(8,6))
                return
            percent = int((i / steps) * 100)
            pb['value'] = percent
            status.config(text=f"{percent}% ...")
            prank.after(500, run_progress, i+1)
        run_progress(0)

    # ----- Code 104: Object attach and activation -----
    def _execute_104(self):
        speak("Object activation sequence complete. Verifying attachment.")
        want = messagebox.askyesno("Code 104", "Proceed with object activation now?")
        if not want:
            speak("Object activation cancelled.")
            self.log("[CODE104] Activation cancelled by user.")
            return
        def do_activation():
            speak("Activating object. Stand by.")
            time.sleep(3)
            speak("Object activated.")
            self.log("[CODE104] Object activated (simulated).")
            messagebox.showinfo("Code 104", "Object activated (simulated).")
        threading.Thread(target=do_activation, daemon=True).start()

    def on_exit_pressed(self):
        if messagebox.askyesno("Exit", "Exit the application?"):
            self.on_exit()

    def shutdown(self):
        try:
            if self.abort_stop:
                self.abort_stop.set()
        except Exception:
            pass

# ---------------- Run ----------------
if __name__ == "__main__":
    speak("Starting Failsafe Console. Please authenticate.")
    app = FailsafeApp()
    app.mainloop()
