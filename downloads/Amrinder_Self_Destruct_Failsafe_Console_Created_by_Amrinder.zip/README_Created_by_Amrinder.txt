========================================================
Voice-Activated Self Destruct Failsafe Console
Created by: Amrinder Pal Singh
========================================================

Inspiration: Star Trek Self-Destruct Sequence ("Computer, this is Amrinder speaking...")
Safety Note: Intentionally avoids non-recoverable system destructive actions. Moves files safely to Recycle Bin.

How to Run:
1. Run: python index.py
2. Command sequence codes: 101, 102, 103, 104
3. Passphrase: 'Computer this is Amrinder speaking'
