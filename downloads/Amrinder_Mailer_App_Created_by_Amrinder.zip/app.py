import os
import sys
import subprocess
required_packages = {'customtkinter': 'customtkinter', 'pandas': 'pandas', 'openpyxl': 'openpyxl'}
missing_packages = []
for import_name, install_name in required_packages.items():
    try:
        __import__(import_name)
    except ImportError:
        missing_packages.append(install_name)
if missing_packages:
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', *missing_packages])
    except Exception as e:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror('Setup Error', f"This app requires missing packages: {', '.join(missing_packages)}.\n\nWe tried to install them automatically, but failed:\n{str(e)}\n\nPlease open a command prompt and run:\npip install customtkinter pandas openpyxl")
        sys.exit(1)
import re
import time
import json
import random
import queue
import threading
import smtplib
import base64
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import customtkinter as ctk
import pandas as pd
ctk.set_appearance_mode('Dark')
ctk.set_default_color_theme('blue')
STATE_FILE = 'mailer_state.json'

class MailerApp(ctk.CTk):

    def __init__(self):
        super().__init__()
        self.title('Universal Email Campaign Mailer')
        self.geometry('1300x850')
        self.minsize(1100, 750)
        try:
            self.state('zoomed')
        except:
            pass
        self.is_sending = False
        self.sending_thread = None
        self.gui_queue = queue.Queue()
        self.file_path = ''
        self.columns = []
        self.recipients = []
        self.current_index = 0
        self.success_count = 0
        self.failure_count = 0
        self.attachment_path = None
        self.load_state()
        self.grid_columnconfigure(0, weight=0, minsize=350)
        self.grid_columnconfigure(1, weight=1, minsize=450)
        self.grid_columnconfigure(2, weight=1, minsize=450)
        self.grid_rowconfigure(0, weight=1)
        self.create_left_panel()
        self.create_middle_panel()
        self.create_right_panel()
        self.process_queue()
        self.populate_ui_from_state()
        self.protocol('WM_DELETE_WINDOW', self.on_closing)

    def load_state(self):
        if os.path.exists(STATE_FILE):
            try:
                with open(STATE_FILE, 'r', encoding='utf-8') as f:
                    self.campaign_state = json.load(f)
            except Exception as e:
                self.campaign_state = {}
                print('Failed to load state file:', e)
        else:
            self.campaign_state = {}
        smtp_data = self.campaign_state.get('smtp', {})
        enc_pass = smtp_data.get('password', '')
        if enc_pass:
            try:
                smtp_data['password'] = base64.b64decode(enc_pass.encode('utf-8')).decode('utf-8')
            except:
                smtp_data['password'] = ''
        campaign = self.campaign_state.get('campaign', {})
        self.file_path = campaign.get('file_path', '')
        self.current_index = campaign.get('current_index', 0)
        self.recipients = campaign.get('recipients', [])
        self.attachment_path = self.campaign_state.get('composer', {}).get('attachment_path', None)
        self.success_count = sum((1 for r in self.recipients if r.get('status') == 'Sent'))
        self.failure_count = sum((1 for r in self.recipients if r.get('status') == 'Failed'))

    def save_state(self):
        smtp_pass = self.entry_smtp_pass.get()
        enc_pass = base64.b64encode(smtp_pass.encode('utf-8')).decode('utf-8') if smtp_pass else ''
        smtp_config = {'preset': self.preset_dropdown.get(), 'server': self.entry_smtp_server.get(), 'port': int(self.entry_smtp_port.get()) if self.entry_smtp_port.get().isdigit() else 465, 'use_ssl': self.check_smtp_ssl.get(), 'username': self.entry_smtp_user.get(), 'password': enc_pass, 'display_name': self.entry_smtp_name.get()}
        composer_config = {'subject': self.entry_subject.get(), 'body': self.txt_body.get('1.0', 'end-1c'), 'attachment_path': self.attachment_path}
        settings_config = {'min_delay': int(self.entry_min_delay.get()) if self.entry_min_delay.get().isdigit() else 60, 'max_delay': int(self.entry_max_delay.get()) if self.entry_max_delay.get().isdigit() else 180, 'batch_limit': int(self.entry_batch_limit.get()) if self.entry_batch_limit.get().isdigit() else 0, 'email_column': self.column_dropdown.get() if hasattr(self, 'column_dropdown') else ''}
        campaign_config = {'file_path': self.file_path, 'current_index': self.current_index, 'recipients': self.recipients}
        self.campaign_state = {'smtp': smtp_config, 'composer': composer_config, 'settings': settings_config, 'campaign': campaign_config}
        try:
            with open(STATE_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.campaign_state, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print('Failed to save state file:', e)

    def populate_ui_from_state(self):
        smtp = self.campaign_state.get('smtp', {})
        self.preset_dropdown.set(smtp.get('preset', 'Gmail (SSL)'))
        self.entry_smtp_server.insert(0, smtp.get('server', ''))
        self.entry_smtp_port.insert(0, str(smtp.get('port', '465')))
        if smtp.get('use_ssl', True):
            self.check_smtp_ssl.select()
        else:
            self.check_smtp_ssl.deselect()
        self.entry_smtp_user.insert(0, smtp.get('username', ''))
        self.entry_smtp_pass.insert(0, smtp.get('password', ''))
        self.entry_smtp_name.insert(0, smtp.get('display_name', ''))
        composer = self.campaign_state.get('composer', {})
        self.entry_subject.insert(0, composer.get('subject', ''))
        self.txt_body.insert('1.0', composer.get('body', ''))
        if self.attachment_path:
            self.lbl_attachment_name.configure(text=os.path.basename(self.attachment_path))
            self.btn_clear_attachment.grid(row=0, column=2, padx=5)
        settings = self.campaign_state.get('settings', {})
        self.entry_min_delay.insert(0, str(settings.get('min_delay', '60')))
        self.entry_max_delay.insert(0, str(settings.get('max_delay', '180')))
        self.entry_batch_limit.insert(0, str(settings.get('batch_limit', '0')))
        if self.file_path and self.recipients:
            self.lbl_file_name.configure(text=os.path.basename(self.file_path))
            self.columns = list(self.recipients[0].keys())
            sel_cols = [c for c in self.columns if c not in ['status', 'error']]
            self.column_dropdown.configure(values=sel_cols)
            saved_col = settings.get('email_column', '')
            if saved_col in sel_cols:
                self.column_dropdown.set(saved_col)
            elif sel_cols:
                self.column_dropdown.set(sel_cols[0])
            self.lbl_placeholders.configure(text='Placeholders: ' + ', '.join([f'{{{c}}}' for c in sel_cols]))
            self.rebuild_treeview()
            self.update_progress_display()
            self.log_message(f'Restored active campaign: {len(self.recipients)} contacts from {os.path.basename(self.file_path)}')

    def create_left_panel(self):
        panel = ctk.CTkFrame(self, corner_radius=0)
        panel.grid(row=0, column=0, sticky='nsew', padx=10, pady=10)
        lbl_title = ctk.CTkLabel(panel, text='SMTP CONFIGURATION', font=ctk.CTkFont(size=13, weight='bold'))
        lbl_title.pack(pady=(10, 5), padx=10, anchor='w')
        lbl_preset = ctk.CTkLabel(panel, text='Preset Provider:', font=ctk.CTkFont(size=10))
        lbl_preset.pack(anchor='w', padx=15, pady=0)
        self.preset_dropdown = ctk.CTkOptionMenu(panel, values=['Gmail (SSL)', 'Gmail (TLS)', 'Outlook (TLS)', 'Custom'], command=self.on_preset_changed, height=24)
        self.preset_dropdown.pack(fill='x', padx=15, pady=(1, 4))
        smtp_grid = ctk.CTkFrame(panel, fg_color='transparent')
        smtp_grid.pack(fill='x', padx=15, pady=0)
        smtp_grid.columnconfigure(0, weight=3)
        smtp_grid.columnconfigure(1, weight=1)
        lbl_serv = ctk.CTkLabel(smtp_grid, text='SMTP Server:', font=ctk.CTkFont(size=10))
        lbl_serv.grid(row=0, column=0, sticky='w', pady=0)
        lbl_port = ctk.CTkLabel(smtp_grid, text='Port:', font=ctk.CTkFont(size=10))
        lbl_port.grid(row=0, column=1, sticky='w', pady=0)
        self.entry_smtp_server = ctk.CTkEntry(smtp_grid, placeholder_text='smtp.gmail.com', height=24)
        self.entry_smtp_server.grid(row=1, column=0, sticky='ew', padx=(0, 5), pady=(1, 4))
        self.entry_smtp_port = ctk.CTkEntry(smtp_grid, placeholder_text='465', height=24)
        self.entry_smtp_port.grid(row=1, column=1, sticky='ew', pady=(1, 4))
        self.check_smtp_ssl = ctk.CTkCheckBox(panel, text='Use SSL Connection', font=ctk.CTkFont(size=10))
        self.check_smtp_ssl.pack(anchor='w', padx=15, pady=(1, 4))
        lbl_user = ctk.CTkLabel(panel, text='Sender Email Address:', font=ctk.CTkFont(size=10))
        lbl_user.pack(anchor='w', padx=15, pady=0)
        self.entry_smtp_user = ctk.CTkEntry(panel, placeholder_text='example@gmail.com', height=24)
        self.entry_smtp_user.pack(fill='x', padx=15, pady=(1, 4))
        lbl_pass = ctk.CTkLabel(panel, text='SMTP / App Password:', font=ctk.CTkFont(size=10))
        lbl_pass.pack(anchor='w', padx=15, pady=0)
        self.entry_smtp_pass = ctk.CTkEntry(panel, placeholder_text='16-character app password', show='*', height=24)
        self.entry_smtp_pass.pack(fill='x', padx=15, pady=(1, 4))
        lbl_name = ctk.CTkLabel(panel, text='Display Sender Name:', font=ctk.CTkFont(size=10))
        lbl_name.pack(anchor='w', padx=15, pady=0)
        self.entry_smtp_name = ctk.CTkEntry(panel, placeholder_text='Your Name (Optional)', height=24)
        self.entry_smtp_name.pack(fill='x', padx=15, pady=(1, 6))
        self.btn_test_smtp = ctk.CTkButton(panel, text='Test SMTP Connection', command=self.run_test_smtp, fg_color='#34495e', hover_color='#2c3e50', height=26)
        self.btn_test_smtp.pack(fill='x', padx=15, pady=(0, 6))
        separator = ctk.CTkFrame(panel, height=2, fg_color='#3f3f3f')
        separator.pack(fill='x', padx=10, pady=6)
        lbl_controls_title = ctk.CTkLabel(panel, text='CAMPAIGN CONTROLS', font=ctk.CTkFont(size=13, weight='bold'))
        lbl_controls_title.pack(pady=2, padx=10, anchor='w')
        delay_frame = ctk.CTkFrame(panel, fg_color='transparent')
        delay_frame.pack(fill='x', padx=15, pady=2)
        delay_frame.columnconfigure(0, weight=1)
        delay_frame.columnconfigure(1, weight=1)
        ctk.CTkLabel(delay_frame, text='Min Delay (sec):', font=ctk.CTkFont(size=10)).grid(row=0, column=0, sticky='w')
        ctk.CTkLabel(delay_frame, text='Max Delay (sec):', font=ctk.CTkFont(size=10)).grid(row=0, column=1, sticky='w')
        self.entry_min_delay = ctk.CTkEntry(delay_frame, placeholder_text='60', height=24)
        self.entry_min_delay.grid(row=1, column=0, sticky='ew', padx=(0, 5), pady=(1, 2))
        self.entry_max_delay = ctk.CTkEntry(delay_frame, placeholder_text='180', height=24)
        self.entry_max_delay.grid(row=1, column=1, sticky='ew', padx=(5, 0), pady=(1, 2))
        lbl_delay_tip = ctk.CTkLabel(delay_frame, text='(Set equal for fixed delay)', font=ctk.CTkFont(size=9, slant='italic'), text_color='#7f8c8d')
        lbl_delay_tip.grid(row=2, column=0, columnspan=2, sticky='w', pady=(0, 2))
        lbl_limit = ctk.CTkLabel(panel, text='Batch Sending Limit (0 = no limit):', font=ctk.CTkFont(size=10))
        lbl_limit.pack(anchor='w', padx=15, pady=0)
        self.entry_batch_limit = ctk.CTkEntry(panel, placeholder_text='0', height=24)
        self.entry_batch_limit.pack(fill='x', padx=15, pady=(1, 4))
        self.lbl_status = ctk.CTkLabel(panel, text='Status: IDLE', font=ctk.CTkFont(size=12, weight='bold'), text_color='#95a5a6')
        self.lbl_status.pack(anchor='w', padx=15, pady=(2, 1))
        self.progress_bar = ctk.CTkProgressBar(panel)
        self.progress_bar.pack(fill='x', padx=15, pady=3)
        self.progress_bar.set(0)
        self.lbl_progress = ctk.CTkLabel(panel, text='Sent: 0 / 0  (Success: 0, Fail: 0)', font=ctk.CTkFont(size=10))
        self.lbl_progress.pack(anchor='w', padx=15, pady=0)
        self.lbl_countdown = ctk.CTkLabel(panel, text='Next Send: N/A', font=ctk.CTkFont(size=10, slant='italic'))
        self.lbl_countdown.pack(anchor='w', padx=15, pady=(0, 6))
        btn_row = ctk.CTkFrame(panel, fg_color='transparent')
        btn_row.pack(fill='x', padx=15, pady=(2, 8))
        btn_row.columnconfigure(0, weight=1)
        btn_row.columnconfigure(1, weight=1)
        btn_row.columnconfigure(2, weight=1)
        self.btn_start = ctk.CTkButton(btn_row, text='Start', fg_color='#27ae60', hover_color='#219653', command=self.start_campaign, height=28)
        self.btn_start.grid(row=0, column=0, padx=(0, 3), sticky='ew')
        self.btn_pause = ctk.CTkButton(btn_row, text='Pause', fg_color='#d35400', hover_color='#b84d00', command=self.pause_campaign, state='disabled', height=28)
        self.btn_pause.grid(row=0, column=1, padx=3, sticky='ew')
        self.btn_reset = ctk.CTkButton(btn_row, text='Reset', fg_color='#c0392b', hover_color='#a83224', command=self.reset_campaign, height=28)
        self.btn_reset.grid(row=0, column=2, padx=(3, 0), sticky='ew')

    def create_middle_panel(self):
        panel = ctk.CTkFrame(self, corner_radius=0)
        panel.grid(row=0, column=1, sticky='nsew', padx=(0, 10), pady=10)
        lbl_title = ctk.CTkLabel(panel, text='EMAIL TEMPLATE COMPOSER', font=ctk.CTkFont(size=14, weight='bold'))
        lbl_title.pack(pady=(15, 10), padx=15, anchor='w')
        lbl_subj = ctk.CTkLabel(panel, text='Email Subject:', font=ctk.CTkFont(size=12, weight='bold'))
        lbl_subj.pack(anchor='w', padx=15, pady=0)
        self.entry_subject = ctk.CTkEntry(panel, placeholder_text='Application for {Position} at {Company}')
        self.entry_subject.pack(fill='x', padx=15, pady=(2, 10))
        lbl_body = ctk.CTkLabel(panel, text='Email Body:', font=ctk.CTkFont(size=12, weight='bold'))
        lbl_body.pack(anchor='w', padx=15, pady=0)
        self.txt_body = ctk.CTkTextbox(panel, wrap='word', font=ctk.CTkFont(family='Consolas', size=12))
        self.txt_body.pack(fill='both', expand=True, padx=15, pady=(2, 8))
        self.lbl_placeholders = ctk.CTkLabel(panel, text='Placeholders: Upload an Excel list to load variable headers.', font=ctk.CTkFont(size=11, slant='italic'), text_color='#bdc3c7', wraplength=400)
        self.lbl_placeholders.pack(anchor='w', padx=15, pady=(0, 8))
        attachment_box = ctk.CTkFrame(panel, fg_color='#2c3e50', height=45)
        attachment_box.pack(fill='x', padx=15, pady=(0, 15))
        attachment_box.grid_propagate(False)
        attachment_box.columnconfigure(0, weight=0)
        attachment_box.columnconfigure(1, weight=1)
        attachment_box.columnconfigure(2, weight=0)
        attachment_box.rowconfigure(0, weight=1)
        self.btn_attach = ctk.CTkButton(attachment_box, text='Attach Resume', command=self.choose_attachment, fg_color='#2980b9', hover_color='#2471a3', width=120)
        self.btn_attach.grid(row=0, column=0, padx=5, pady=5, sticky='w')
        self.lbl_attachment_name = ctk.CTkLabel(attachment_box, text='No resume attached (PDF/Word)', font=ctk.CTkFont(size=11), anchor='w', text_color='#bdc3c7')
        self.lbl_attachment_name.grid(row=0, column=1, padx=5, pady=5, sticky='ew')
        self.btn_clear_attachment = ctk.CTkButton(attachment_box, text='Remove', command=self.clear_attachment, fg_color='#e74c3c', hover_color='#c0392b', width=60)
        self.btn_clear_attachment.grid_forget()

    def create_right_panel(self):
        panel = ctk.CTkFrame(self, corner_radius=0)
        panel.grid(row=0, column=2, sticky='nsew', padx=(0, 10), pady=10)
        lbl_title = ctk.CTkLabel(panel, text='TARGET LIST & PROGRESS', font=ctk.CTkFont(size=14, weight='bold'))
        lbl_title.pack(pady=(15, 5), padx=15, anchor='w')
        load_grid = ctk.CTkFrame(panel, fg_color='transparent')
        load_grid.pack(fill='x', padx=15, pady=5)
        load_grid.columnconfigure(0, weight=1)
        load_grid.columnconfigure(1, weight=1)
        self.btn_load_file = ctk.CTkButton(load_grid, text='Select Email List', command=self.load_recipients_file, fg_color='#9b59b6', hover_color='#8e44ad')
        self.btn_load_file.grid(row=0, column=0, sticky='ew', padx=(0, 5), pady=0)
        self.column_dropdown = ctk.CTkOptionMenu(load_grid, values=['Email Column: Load file first'])
        self.column_dropdown.grid(row=0, column=1, sticky='ew', padx=(5, 0), pady=0)
        self.lbl_file_name = ctk.CTkLabel(panel, text='No email list loaded (.xlsx, .csv)', font=ctk.CTkFont(size=11, slant='italic'))
        self.lbl_file_name.pack(anchor='w', padx=15, pady=(2, 8))
        tree_frame = ctk.CTkFrame(panel, fg_color='transparent')
        tree_frame.pack(fill='both', expand=True, padx=15, pady=5)
        style = ttk.Style()
        style.theme_use('default')
        style.configure('Treeview', background='#2d3748', foreground='#ffffff', rowheight=25, fieldbackground='#2d3748', bordercolor='#3f4e66', borderwidth=0, font=('Segoe UI', 10))
        style.map('Treeview', background=[('selected', '#1f538d')])
        style.configure('Treeview.Heading', background='#4a5568', foreground='#ffffff', font=('Segoe UI', 10, 'bold'), relief='flat')
        style.map('Treeview.Heading', background=[('active', '#2b6cb0')])
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side='right', fill='y')
        self.tree = ttk.Treeview(tree_frame, columns=('#', 'Email', 'Status', 'Details'), show='headings', yscrollcommand=scrollbar.set)
        self.tree.pack(fill='both', expand=True)
        scrollbar.config(command=self.tree.yview)
        self.tree.heading('#', text='#', anchor='center')
        self.tree.heading('Email', text='Email Address', anchor='w')
        self.tree.heading('Status', text='Status', anchor='center')
        self.tree.heading('Details', text='Status Details', anchor='w')
        self.tree.column('#', width=40, minwidth=40, anchor='center')
        self.tree.column('Email', width=180, minwidth=150, anchor='w')
        self.tree.column('Status', width=80, minwidth=80, anchor='center')
        self.tree.column('Details', width=130, minwidth=100, anchor='w')
        separator = ctk.CTkFrame(panel, height=2, fg_color='#3f3f3f')
        separator.pack(fill='x', padx=10, pady=10)
        lbl_log_title = ctk.CTkLabel(panel, text='LIVE ACTIVITY LOG', font=ctk.CTkFont(size=12, weight='bold'))
        lbl_log_title.pack(anchor='w', padx=15, pady=0)
        self.txt_log = ctk.CTkTextbox(panel, height=150, font=ctk.CTkFont(family='Consolas', size=11), wrap='word')
        self.txt_log.pack(fill='x', padx=15, pady=(2, 15))
        self.txt_log.configure(state='disabled')

    def on_preset_changed(self, choice):
        self.entry_smtp_server.delete(0, 'end')
        self.entry_smtp_port.delete(0, 'end')
        self.check_smtp_ssl.deselect()
        if choice == 'Gmail (SSL)':
            self.entry_smtp_server.insert(0, 'smtp.gmail.com')
            self.entry_smtp_port.insert(0, '465')
            self.check_smtp_ssl.select()
        elif choice == 'Gmail (TLS)':
            self.entry_smtp_server.insert(0, 'smtp.gmail.com')
            self.entry_smtp_port.insert(0, '587')
        elif choice == 'Outlook (TLS)':
            self.entry_smtp_server.insert(0, 'smtp-mail.outlook.com')
            self.entry_smtp_port.insert(0, '587')
        elif choice == 'Custom':
            pass

    def choose_attachment(self):
        file = filedialog.askopenfilename(title='Select Resume File', filetypes=[('PDF/Word Documents', '*.pdf *.docx *.doc'), ('All Files', '*.*')])
        if file:
            self.attachment_path = file
            self.lbl_attachment_name.configure(text=os.path.basename(file), text_color='#ffffff')
            self.btn_clear_attachment.grid(row=0, column=2, padx=5)
            self.save_state()

    def clear_attachment(self):
        self.attachment_path = None
        self.lbl_attachment_name.configure(text='No resume attached (PDF/Word)', text_color='#bdc3c7')
        self.btn_clear_attachment.grid_forget()
        self.save_state()

    def load_recipients_file(self):
        file = filedialog.askopenfilename(title='Select Email List Sheet', filetypes=[('Excel Sheets', '*.xlsx *.xls'), ('CSV CSVs', '*.csv'), ('All Files', '*.*')])
        if not file:
            return
        if self.file_path == file and len(self.recipients) > 0 and (self.current_index > 0):
            ans = messagebox.askyesnocancel('Resume Campaign?', f'You have an active campaign on this file with {self.current_index}/{len(self.recipients)} emails sent.\nDo you want to RESUME where you left off?\n\nClick YES to resume, NO to restart a fresh campaign with this file, or CANCEL.')
            if ans is None:
                return
            elif ans is True:
                self.log_message(f'Resuming campaign from index {self.current_index} for {os.path.basename(file)}')
                return
        self.file_path = file
        self.lbl_file_name.configure(text=os.path.basename(file))
        self.log_message(f'Loading file: {os.path.basename(file)}...')
        try:
            ext = os.path.splitext(file)[1].lower()
            if ext == '.csv':
                df = pd.read_csv(file)
            else:
                df = pd.read_excel(file)
            df = df.fillna('')
            self.columns = list(df.columns)
            sel_cols = [c for c in self.columns if c not in ['status', 'error']]
            self.column_dropdown.configure(values=sel_cols)
            if sel_cols:
                matching = [c for c in sel_cols if 'email' in c.lower()]
                if matching:
                    self.column_dropdown.set(matching[0])
                else:
                    self.column_dropdown.set(sel_cols[0])
                self.lbl_placeholders.configure(text='Placeholders: ' + ', '.join([f'{{{c}}}' for c in sel_cols]))
            self.recipients = []
            for r in df.to_dict(orient='records'):
                r['status'] = 'Pending'
                r['error'] = ''
                self.recipients.append(r)
            self.current_index = 0
            self.success_count = 0
            self.failure_count = 0
            self.rebuild_treeview()
            self.update_progress_display()
            self.save_state()
            self.log_message(f'SUCCESS: Loaded {len(self.recipients)} rows from {os.path.basename(file)}')
        except Exception as e:
            self.log_message(f'FAILED TO LOAD FILE: {str(e)}')
            messagebox.showerror('Error', f'Could not read spreadsheet file:\n{str(e)}')

    def rebuild_treeview(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        email_col = self.column_dropdown.get()
        if not email_col or email_col.startswith('Email Column:'):
            email_col = 'Email' if 'Email' in self.columns else self.columns[0] if self.columns else ''
        for idx, rec in enumerate(self.recipients):
            email = rec.get(email_col, 'N/A')
            status = rec.get('status', 'Pending')
            details = rec.get('error', '')
            tag = status.lower()
            self.tree.insert('', 'end', iid=str(idx), values=(idx + 1, email, status, details), tags=(tag,))
        self.tree.tag_configure('sent', foreground='#2ecc71')
        self.tree.tag_configure('failed', foreground='#e74c3c')
        self.tree.tag_configure('pending', foreground='#ffffff')

    def update_progress_display(self):
        total = len(self.recipients)
        if total > 0:
            ratio = self.current_index / total
            self.progress_bar.set(ratio)
        else:
            self.progress_bar.set(0)
        self.lbl_progress.configure(text=f'Sent: {self.current_index} / {total}  (Success: {self.success_count}, Fail: {self.failure_count})')

    def run_test_smtp(self):
        username = self.entry_smtp_user.get().strip()
        password = self.entry_smtp_pass.get().strip()
        server_ip = self.entry_smtp_server.get().strip()
        port_str = self.entry_smtp_port.get().strip()
        use_ssl = self.check_smtp_ssl.get()
        if not username or not password or (not server_ip) or (not port_str):
            messagebox.showwarning('Incomplete Details', 'Please fill in all SMTP Server fields first.')
            return
        self.btn_test_smtp.configure(state='disabled', text='Testing...')
        self.log_message('Testing SMTP connection. Please wait...')
        smtp_config = {'username': username, 'password': password, 'server': server_ip, 'port': int(port_str), 'use_ssl': use_ssl}
        threading.Thread(target=self.test_smtp_worker, args=(smtp_config,), daemon=True).start()

    def test_smtp_worker(self, config):
        server = None
        try:
            if config['use_ssl']:
                server = smtplib.SMTP_SSL(config['server'], config['port'], timeout=12)
            else:
                server = smtplib.SMTP(config['server'], config['port'], timeout=12)
                server.starttls()
            server.login(config['username'], config['password'])
            self.gui_queue.put(('TEST_SMTP_RESULT', True, 'Connection Successful! Login works.'))
        except Exception as e:
            self.gui_queue.put(('TEST_SMTP_RESULT', False, f'Connection Failed: {str(e)}'))
        finally:
            if server:
                try:
                    server.quit()
                except:
                    pass

    def start_campaign(self):
        if self.is_sending:
            return
        if not self.recipients:
            messagebox.showwarning('No Contacts', 'Please load an Excel/CSV list of emails first.')
            return
        email_col = self.column_dropdown.get()
        if not email_col or email_col.startswith('Email Column:'):
            messagebox.showwarning('Select Email Column', 'Please select which column contains the email addresses.')
            return
        username = self.entry_smtp_user.get().strip()
        password = self.entry_smtp_pass.get().strip()
        server_ip = self.entry_smtp_server.get().strip()
        port_str = self.entry_smtp_port.get().strip()
        if not username or not password or (not server_ip) or (not port_str):
            messagebox.showwarning('SMTP Missing', 'Please input complete SMTP details in the configurations panel.')
            return
        subject = self.entry_subject.get().strip()
        body = self.txt_body.get('1.0', 'end-1c').strip()
        if not subject or not body:
            messagebox.showwarning('Mail Template Empty', 'Subject and Body template cannot be empty.')
            return
        try:
            min_delay = int(self.entry_min_delay.get())
            max_delay = int(self.entry_max_delay.get())
            batch_limit = int(self.entry_batch_limit.get())
            if min_delay < 0 or max_delay < min_delay or batch_limit < 0:
                raise ValueError
        except ValueError:
            messagebox.showwarning('Invalid Delays/Limit', 'Please enter positive integer numbers for delays and limit. Min delay cannot exceed Max delay.')
            return
        if self.current_index >= len(self.recipients):
            ans = messagebox.askyesno('Campaign Complete', 'All contacts in the loaded queue have already been processed.\nWould you like to reset progress and restart from the beginning?')
            if ans:
                self.reset_campaign()
            return
        self.save_state()
        self.is_sending = True
        self.btn_start.configure(state='disabled')
        self.btn_pause.configure(state='normal')
        self.btn_reset.configure(state='disabled')
        self.btn_load_file.configure(state='disabled')
        self.column_dropdown.configure(state='disabled')
        self.lbl_status.configure(text='Status: SENDING...', text_color='#2ecc71')
        smtp_config = {'server': server_ip, 'port': int(port_str), 'username': username, 'password': password, 'use_ssl': self.check_smtp_ssl.get(), 'display_name': self.entry_smtp_name.get()}
        self.log_message('Campaign Started.')
        self.sending_thread = threading.Thread(target=self.sending_worker, args=(smtp_config, subject, body, email_col, min_delay, max_delay, batch_limit), daemon=True)
        self.sending_thread.start()

    def pause_campaign(self):
        if not self.is_sending:
            return
        self.is_sending = False
        self.btn_pause.configure(state='disabled', text='Pausing...')
        self.log_message('Pause requested. Waiting for current process to finish...')

    def reset_campaign(self):
        if self.is_sending:
            return
        if not self.recipients:
            return
        ans = messagebox.askyesno('Confirm Reset', "Are you sure you want to reset the current campaign progress?\nThis will reset all contacts back to 'Pending'.")
        if not ans:
            return
        self.current_index = 0
        self.success_count = 0
        self.failure_count = 0
        for r in self.recipients:
            r['status'] = 'Pending'
            r['error'] = ''
        self.rebuild_treeview()
        self.update_progress_display()
        self.lbl_countdown.configure(text='Next Send: N/A')
        self.lbl_status.configure(text='Status: IDLE', text_color='#95a5a6')
        self.save_state()
        self.log_message('Campaign progress reset to beginning.')

    def sending_worker(self, smtp_config, subject_template, body_template, email_col, min_delay, max_delay, batch_limit):
        total = len(self.recipients)
        sent_this_session = 0
        while self.is_sending and self.current_index < total:
            if batch_limit > 0 and sent_this_session >= batch_limit:
                self.gui_queue.put(('LOG', f'BATCH LIMIT REACHED: Paused after sending {sent_this_session} emails this session.'))
                self.is_sending = False
                break
            rec = self.recipients[self.current_index]
            if rec.get('status') == 'Sent':
                self.current_index += 1
                self.gui_queue.put(('PROGRESS_UPDATE',))
                continue
            to_email = rec.get(email_col, '').strip()
            if not to_email:
                rec['status'] = 'Failed'
                rec['error'] = f'Missing email column data in row {self.current_index + 1}'
                self.failure_count += 1
                self.gui_queue.put(('ROW_STATUS', self.current_index, 'Failed', rec['error']))
                self.current_index += 1
                self.gui_queue.put(('PROGRESS_UPDATE',))
                continue
            self.gui_queue.put(('ROW_STATUS', self.current_index, 'Sending...', ''))
            self.gui_queue.put(('LOG', f'Sending email ({self.current_index + 1}/{total}) to {to_email}...'))
            personalization = {}
            for k, v in rec.items():
                if k not in ['status', 'error']:
                    personalization[k] = str(v)
            sub = subject_template
            body = body_template
            body = '\n'.join([line for line in body.split('\n') if not line.strip().startswith('#') and (not line.strip().startswith('//'))])
            for k, v in personalization.items():
                sub = sub.replace(f'{{{k}}}', v)
                body = body.replace(f'{{{k}}}', v)
            msg = MIMEMultipart()
            disp_name = smtp_config.get('display_name', '')
            if disp_name:
                msg['From'] = f"{disp_name} <{smtp_config['username']}>"
            else:
                msg['From'] = smtp_config['username']
            msg['To'] = to_email
            msg['Subject'] = sub
            attach_path = self.attachment_path
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            has_attachment = False
            if attach_path and os.path.exists(attach_path):
                try:
                    filename = os.path.basename(attach_path)
                    with open(attach_path, 'rb') as f:
                        part = MIMEBase('application', 'octet-stream')
                        part.set_payload(f.read())
                    encoders.encode_base64(part)
                    part.add_header('Content-Disposition', f'attachment; filename="{filename}"')
                    msg.attach(part)
                    has_attachment = True
                except Exception as ex:
                    rec['status'] = 'Failed'
                    rec['error'] = f'Failed to attach file: {str(ex)}'
                    self.failure_count += 1
                    self.gui_queue.put(('ROW_STATUS', self.current_index, 'Failed', rec['error']))
                    self.gui_queue.put(('LOG', f'ERROR: Failed to attach resume for {to_email}: {str(ex)}'))
                    self.current_index += 1
                    self.gui_queue.put(('PROGRESS_UPDATE',))
                    self.save_state()
                    continue
            server = None
            try:
                if smtp_config['use_ssl']:
                    server = smtplib.SMTP_SSL(smtp_config['server'], smtp_config['port'], timeout=15)
                else:
                    server = smtplib.SMTP(smtp_config['server'], smtp_config['port'], timeout=15)
                    server.starttls()
                server.login(smtp_config['username'], smtp_config['password'])
                server.sendmail(smtp_config['username'], to_email, msg.as_string())
                rec['status'] = 'Sent'
                rec['error'] = ''
                self.success_count += 1
                self.gui_queue.put(('ROW_STATUS', self.current_index, 'Sent', ''))
                self.gui_queue.put(('LOG', f'SUCCESS: Sent to {to_email}' + (' (with attachment)' if has_attachment else '')))
            except Exception as err:
                rec['status'] = 'Failed'
                rec['error'] = str(err)
                self.failure_count += 1
                self.gui_queue.put(('ROW_STATUS', self.current_index, 'Failed', str(err)))
                self.gui_queue.put(('LOG', f'ERROR: Failed sending to {to_email} - {str(err)}'))
            finally:
                if server:
                    try:
                        server.quit()
                    except:
                        pass
            self.current_index += 1
            sent_this_session += 1
            self.gui_queue.put(('PROGRESS_UPDATE',))
            self.save_state()
            if self.is_sending and self.current_index < total:
                delay = random.randint(min_delay, max_delay)
                self.gui_queue.put(('LOG', f'Waiting {delay} seconds before sending next email...'))
                for rem in range(delay, 0, -1):
                    if not self.is_sending:
                        break
                    self.gui_queue.put(('COUNTDOWN', f'Next Send: in {rem}s'))
                    for _ in range(10):
                        if not self.is_sending:
                            break
                        time.sleep(0.1)
        self.gui_queue.put(('CAMPAIGN_FINISHED',))

    def process_queue(self):
        try:
            while True:
                msg = self.gui_queue.get_nowait()
                msg_type = msg[0]
                if msg_type == 'LOG':
                    self.log_message(msg[1])
                elif msg_type == 'TEST_SMTP_RESULT':
                    success = msg[1]
                    info = msg[2]
                    self.btn_test_smtp.configure(state='normal', text='Test SMTP Connection')
                    self.log_message(info)
                    if success:
                        messagebox.showinfo('SMTP Success', info)
                    else:
                        messagebox.showerror('SMTP Failed', info)
                elif msg_type == 'ROW_STATUS':
                    row_idx = msg[1]
                    status = msg[2]
                    details = msg[3]
                    self.tree.item(str(row_idx), values=(row_idx + 1, self.recipients[row_idx].get(self.column_dropdown.get(), 'N/A'), status, details))
                    self.tree.set(str(row_idx), 'Status', status)
                    self.tree.set(str(row_idx), 'Details', details)
                    self.tree.item(str(row_idx), tags=(status.lower().replace('...', ''),))
                    self.tree.see(str(row_idx))
                elif msg_type == 'PROGRESS_UPDATE':
                    self.update_progress_display()
                elif msg_type == 'COUNTDOWN':
                    self.lbl_countdown.configure(text=msg[1])
                elif msg_type == 'CAMPAIGN_FINISHED':
                    self.is_sending = False
                    self.btn_start.configure(state='normal')
                    self.btn_pause.configure(state='disabled', text='Pause')
                    self.btn_reset.configure(state='normal')
                    self.btn_load_file.configure(state='normal')
                    self.column_dropdown.configure(state='normal')
                    self.lbl_countdown.configure(text='Next Send: N/A')
                    total = len(self.recipients)
                    if self.current_index >= total:
                        self.lbl_status.configure(text='Status: COMPLETED', text_color='#3498db')
                        self.log_message('Campaign Finished! All emails processed.')
                        messagebox.showinfo('Campaign Completed', 'Email campaign processing has finished!')
                    else:
                        self.lbl_status.configure(text='Status: PAUSED', text_color='#e67e22')
                        self.log_message('Campaign Paused.')
                        messagebox.showinfo('Campaign Paused', 'Email campaign sending was paused successfully.')
                    self.save_state()
        except queue.Empty:
            pass
        self.after(100, self.process_queue)

    def log_message(self, message):
        timestamp = time.strftime('%H:%M:%S')
        formatted = f'[{timestamp}] {message}\n'
        self.txt_log.configure(state='normal')
        self.txt_log.insert('end', formatted)
        self.txt_log.see('end')
        self.txt_log.configure(state='disabled')

    def on_closing(self):
        if self.is_sending:
            if not messagebox.askyesno('Exit App', 'An email campaign is currently sending. Are you sure you want to stop it and exit?'):
                return
            self.is_sending = False
        self.save_state()
        self.destroy()
if __name__ == '__main__':
    app = MailerApp()
    app.mainloop()