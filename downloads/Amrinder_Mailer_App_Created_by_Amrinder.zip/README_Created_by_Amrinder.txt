========================================================
Universal Bulk Email Campaign Mailer
Created by: Amrinder Pal Singh
========================================================

How to Run:
1. Install dependencies: pip install customtkinter pandas openpyxl
2. Run app: python app.py
3. Features: CustomTkinter GUI email manager, Excel bulk recipient loader, campaign state persistence.
